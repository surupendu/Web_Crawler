# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
from scrapy.contrib.exporter import XmlItemExporter
import hashlib

class AnandaTrialPipeline(object):
 
    def process_item(self, item, spider):
        #name = item['docid']
        self.file = open("D:\\Dataset\\"+ item['DOCID'] +".xml",'wb')
        self.exporter = XmlItemExporter(self.file,item_element='BODY',root_element='DOC',encoding='utf-8',indent=5)
        self.exporter.start_exporting()
        self.exporter.export_item(item)
        self.exporter.finish_exporting()
        self.file.close()
        return item
