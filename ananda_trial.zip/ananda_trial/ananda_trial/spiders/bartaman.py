# -*- coding: utf-8 -*-
import scrapy
import hashlib
from scrapy.linkextractors import LinkExtractor

class BartamanSpider(scrapy.Spider):
    name = 'bartaman'
    allowed_domains = ['bartamanpatrika.com']
    start_urls = ['http://bartamanpatrika.com/','http://bartamanpatrika.com/section.php?cID=12','http://bartamanpatrika.com/section.php?cID=13',
                  'http://bartamanpatrika.com/section.php?cID=14','http://bartamanpatrika.com/section.php?cID=15','http://bartamanpatrika.com/section.php?cID=16',
                  'http://bartamanpatrika.com/section.php?cID=17','http://bartamanpatrika.com/section.php?cID=18','http://bartamanpatrika.com/section.php?cID=19',
                  'http://bartamanpatrika.com/section.php?cID=45','http://bartamanpatrika.com/horoscope.php?cID=25','http://bartamanpatrika.com/section.php?cID=30',
                  'http://bartamanpatrika.com/section.php?cID=27','http://bartamanpatrika.com/section.php?cID=28','http://bartamanpatrika.com/section.php?cID=29']

    def parse(self,response):
        lnkex = LinkExtractor(unique=True,strip=True)
        links = lnkex.extract_links(response)
        for link in links:
            yield scrapy.http.Request(link.url,callback=self.extract_info)
        
    
    def extract_info(self,response):
        #reponse.follow(link,callback=self.extract_info)
        Title = response.css('.head-news').xpath('./h4/strong/text()').extract()
        Date = response.css('.abp-story-date-div::text').extract()
        Article = response.css('.content').xpath('./div/text()').extract()

        text = ""
        title = ""
        date_time = ""
                
        for para in Article:
            text = text + "\n" +para

        for sent in Title:
            title = title + sent

        for dt in Date:
            date_time = date_time + " " + dt

        if text!="":
            temp = title.encode()
            m = hashlib.md5(temp)
            scraped_info = {
                    'DOCID' : str(m.hexdigest()),
                    'TITLE' : title,
                    'DATE' : date_time,
                    'ARTICLE' : text
                }
            yield scraped_info
