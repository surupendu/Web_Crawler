# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
import hashlib

class AnandatrialSpider(scrapy.Spider):
    name = 'anandatrial'
    allowed_domains = ['http://www.anandabazar.com/national/supreme-court-order-changed-the-entire-political-game-in-karnataka-dgtl-1.801943?ref=hm-ft-stry-center-1']
    start_urls = ['http://www.anandabazar.com/national/supreme-court-order-changed-the-entire-political-game-in-karnataka-dgtl-1.801943?ref=hm-ft-stry-center-1']

    def parse(self, response):

        #links = LinkExtractor(canonicalize=True, unique=True).extract_links(response)
        #for link in links:   
        Title = response.css('h1::text').extract()
        Date = response.css('.abp-story-date-div::text').extract()
        Article = response.css('p::text').extract()

        text = ""
        title = ""
        date_time = ""
        
        for para in Article:
            text = text + "\n" +para

        for sent in Title:
            title = title + sent

        for dt in Date:
            date_time = date_time + " " + dt

        temp = title.encode()
        m = hashlib.md5(temp)
        scraped_info = {
                'DOCID' : str(m.hexdigest()),
                'TITLE' : title,
                'DATE' : date_time,
                'ARTICLE' : text
            }

        yield scraped_info

        
