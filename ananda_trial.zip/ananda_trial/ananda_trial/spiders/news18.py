# -*- coding: utf-8 -*-
import scrapy
import hashlib
from scrapy.linkextractors import LinkExtractor

class News18Spider(scrapy.Spider):
    name = 'news18'
    allowed_domains = ['bengali.news18.com']
    start_urls = ['https://bengali.news18.com/','https://bengali.news18.com/kolkata/','https://bengali.news18.com/national/',
                  'https://bengali.news18.com/international/','https://bengali.news18.com/sports/','https://bengali.news18.com/life-style/',
                  'https://bengali.news18.com/entertainment/']

    def parse(self,response):
        lnkex = LinkExtractor(unique=True,strip=True)
        links = lnkex.extract_links(response)
        for link in links:
            yield scrapy.http.Request(link.url,callback=self.extract_info)
        
    
    def extract_info(self,response):
        #reponse.follow(link,callback=self.extract_info)
        Title = response.css('.article_box').xpath('//h1//text()').extract()
        Date = response.css('.bynow-text::text').extract()
        Article = response.css('p::text').extract()

        #Date1 = Date[3]
        text = ""
        title = ""
        date_time = ""
                
        for para in Article:
            text = text + "\n" +para

        for sent in Title:
            title = title + sent

        for dt in Date:
            date_time = date_time + " " + dt

        if text!="" and date_time!="":
            temp = title.encode()
            m = hashlib.md5(temp)
            scraped_info = {
                    'DOCID' : str(m.hexdigest()),
                    'TITLE' : title,
                    'DATE' : date_time,
                    'ARTICLE' : text
                }
            yield scraped_info

