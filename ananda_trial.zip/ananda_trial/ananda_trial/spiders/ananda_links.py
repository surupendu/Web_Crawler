# -*- coding: utf-8 -*-
import scrapy
import hashlib
from scrapy.linkextractors import LinkExtractor

class AnandaLinksSpider(scrapy.Spider):
    name = 'ananda_links'
    allowed_domains = ['anandabazar.com']
    start_urls = ['http://www.anandabazar.com//','http://www.anandabazar.com/supplementary/pustokporichoi?ref=','http://www.anandabazar.com/supplementary/kolkatakorcha?ref=','http://www.anandabazar.com/supplementary/patrika?ref=','http://www.anandabazar.com/supplementary/rabibashoriyo?ref=','http://www.anandabazar.com/calcutta?ref=hm-Footer',
            'http://www.anandabazar.com/state?ref=hm-Footer',
            'http://www.anandabazar.com/national?ref=hm-Footer',
            'http://www.anandabazar.com/international?ref=hm-Footer',
            'http://www.anandabazar.com/sport?ref=hm-Footer',
            'http://www.anandabazar.com/entertainment?ref=hm-Footer',
            'http://www.anandabazar.com/business?ref=hm-Footer',
            'http://www.anandabazar.com/others/science?ref=hm-Footer',
            'http://www.anandabazar.com/others/bhromon?ref=hm-Footer',
            'http://www.anandabazar.com/bangladesh-news?ref=hm-Footer',
            'http://www.anandabazar.com/editorial?ref=hm-Footer',
            'http://www.anandabazar.com/lifestyle?ref=hm-Footer',
            'http://www.anandabazar.com/district/north-bengal?ref=hm-Footer',
            'http://www.anandabazar.com/district/howrah-hoogly?ref=hm-Footer',
            'http://www.anandabazar.com/district/24-paraganas?ref=hm-Footer',
            'http://www.anandabazar.com/district/nadia-murshidabad?ref=hm-Footer',
            'http://www.anandabazar.com/district/purulia-birbhum-bankura?ref=hm-Footer',
            'http://www.anandabazar.com/district/bardhaman?ref=hm-Footer',
            'http://www.anandabazar.com/district/midnapore?ref=hm-Footer',
            'http://www.anandabazar.com/others/weather?ref=hm-Footer',
            'http://www.anandabazar.com/lifestyle?ref=',
            'http://www.anandabazar.com/women?ref=',
            'http://www.anandabazar.com/travel?ref='
        ]

    def parse(self,response):
        lnkex = LinkExtractor(unique=True,strip=True)
        links = lnkex.extract_links(response)
        for link in links:
            yield scrapy.http.Request(link.url,callback=self.extract_info)
        
    
    def extract_info(self,response):
        #reponse.follow(link,callback=self.extract_info)
        Title = response.css('h1::text').extract()
        Date = response.css('.abp-story-date-div::text').extract()
        Article = response.css('p::text').extract()

        text = ""
        title = ""
        date_time = ""
                
        for para in Article:
            text = text + "\n" +para

        for sent in Title:
            title = title + sent

        for dt in Date:
            date_time = date_time + " " + dt

        if text!="" and date_time!="":
            temp = title.encode()
            m = hashlib.md5(temp)
            scraped_info = {
                    'DOCID' : str(m.hexdigest()),
                    'TITLE' : title,
                    'DATE' : date_time,
                    'ARTICLE' : text
                }
            yield scraped_info
        
